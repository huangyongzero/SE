package test;

import junit.Canlonder;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class CanlonderTest {
    /**
     *申请资源
     */
    @Before
    public void init(){
        System.out.println("init...");
    }
    /**
     * 关闭资源
     */
    @After
    public void close(){
        System.out.println("close...");
    }
    /**
     *测试方法
     */
    @Test
    public void testAdd(){
        System.out.println("我被执行了！");
        Canlonder c=new Canlonder();
        int result=c.add(1,2);
        System.out.println(result);
        Assert.assertEquals(3,result);
//        int result0=c.sub(2,3);
//        System.out.println(result0);
    }
}
